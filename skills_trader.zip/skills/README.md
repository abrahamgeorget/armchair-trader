# Claude Code skills

The daily run is partly code (`src/`) and partly these Claude Code skills. A skill is a set of instructions Claude follows step by step: it runs the scripts, does the research a script can't (news, filings, analyst notes), and applies the judgement rules written here.

| Skill | Market | Daily-run step | What it does |
|---|---|---|---|
| [`qsx-stock-aggresive`](qsx-stock-aggresive/SKILL.md) | TSX | 2-4 | Runs the screen, verifies a fresh catalyst for each candidate, writes the shortlist to `List_agg` |
| [`qsx-nasdaq-aggressive`](qsx-nasdaq-aggressive/SKILL.md) | Nasdaq | 2-4 | Same flow for Nasdaq (USD, ONEQ proxy, Nasdaq-specific gates), writes to `List_agg_NASDAQ` |
| [`cautious-trader-verdict`](cautious-trader-verdict/SKILL.md) | Both | 5 | Second opinion per pick: hard vetoes plus a 10-point scorecard, then BUY / BUY-HALF / NO-BUY |

All three are v2, rewritten after the October 2026 backtests (see `docs/`). The versions Claude actually runs live in Claude's skill settings; these copies are kept in sync by hand.
