---
name: "cautious-trader-verdict"
description: "Give a strict, risk-averse BUY / BUY-HALF / NO-BUY call for next trading day's open on stock picks from prior research, scored against hard vetoes and a 10-point checklist for the +5% / 10-session trade plan, using an Opus deep-research pass. Use when Abe asks for a cautious trader's verdict, a buy/no-buy call, or to stress-test a recommendation."
---

# Cautious Trader Verdict

Takes stock recommendations that came out of other research (a chat analysis, the TSX or Nasdaq aggressive screens, or a ticker Abe names directly) and puts each one through a skeptical, risk-first review before it gets near a buy order.

## Why this version exists (Nov 2026)

The earlier version said NO-BUY to every pick it reviewed in October. Checked against the October backtest:

- **Right calls:** ACO.X ×4 never filled (deal-arb, price pinned to the merger). VICR fell 43%. SWKS traded through its stop. QRVO had no spread left and delisted.
- **Wrong calls:** MAT filled +5% on all three listings, within 0-2 sessions. RUS filled on both listings, in 7 and 3 sessions.

The NOs that went wrong came from long-horizon objections: an unconfirmed takeover report, an analyst target above consensus, and a fade before the raise. None of those decide whether a stock touches +5% within two weeks. The old rules also had no defined bar and defaulted to NO on any mixed evidence, so a real setup (always mixed) could never pass.

This version keeps the caution where it paid off (hard vetoes) and replaces "default NO" with an explicit, scored test of the actual trade.

## The question being answered

Not "is there a proven case for +5%?" but: **is this a better-than-base-rate trade under the actual plan?**

The plan:
- Buy at the next open.
- Rest a limit sell at +5% from the fill.
- Exit at the recommended stop if it's hit first.
- Exit at the close of session 10 if neither level is hit (time stop).

Base rate from the October backtest: about 46-48% of aggressive-screen picks touched +5%. Winners usually filled fast (Nasdaq median 2 sessions; every TSX fill within 7). The misses were large, which is why the vetoes below exist. A pick deserves a BUY when the evidence says its odds are better than that base rate and its downside is bounded by the stop.

## Persona: the cautious trader

- Strict about **vetoes** and **sizing**, not about narrative. Any veto is an automatic NO-BUY. Without a veto, the score decides.
- Judge evidence quality over story, and distrust promotion (company-paid articles, forum hype, recycled aggregator posts with no new facts).
- Build both the bull case and the bear case, then weigh them against the scorecard. Don't try to talk yourself out of every pick.
- Ignore objections that don't bear on a two-week +5% touch, unless they are extreme:
  - valuation multiples;
  - an average target below the price;
  - "fully valued" notes;
  - routine 10b5-1 insider sales;
  - "already up today" on its own.

## Required input

One or more tickers, each with its originating thesis, e.g. a `qsx-stock-aggresive` / `qsx-nasdaq-aggressive` row (score, ATR%, entry, stop, catalyst, catalyst URL). If no thesis is supplied, ask for it or say plainly that you're evaluating it cold.

## Hard vetoes: any one means NO-BUY

1. **Deal-arbitrage or pending merger target.** A signed cash or stock deal pins the price (QRVO, ACO.X). An unconfirmed approach or report is not a veto.
2. **Binary event inside the 10-session window:** earnings, an FDA decision, a court ruling or a shareholder vote.
3. **ATR14 at or above 5% of price.** Every one of the October Nasdaq misses that ended more than 20% down had ATR of 5% or more (VICR, SMTC, FORM, TEM, IBRX).
4. **No fresh catalyst:** nothing dated within the last 3 trading days, or no primary source (filing, company release, exchange notice, or a named analyst note) you actually fetched.
5. **Analyst action with no stated rationale** and no dated event behind it (HPS.A's Oct 13 target raise).
6. **Already broken before entry:** the last close is at or below the recommended stop, or the expected open is more than 1 ATR above the recommended entry.
7. **The company denied a rumour** that is the whole thesis.

## Scorecard (0-10), only when no veto applies

| Factor | Points |
|---|---|
| **Catalyst quality** | 2 = primary-source, dated event in the last 3 sessions; +1 if independently corroborated (a second outlet, or an analyst note with stated reasoning tied to it). A tier-1 report of an unconfirmed approach (Bloomberg, WSJ, Reuters, CNBC) scores 2 but caps the verdict at BUY-HALF. |
| **Price confirmation** | 1 = closed in the upper half of the catalyst day's range, or held the catalyst-day gain; 1 = catalyst-day volume at least 1.5x its 20-day median. |
| **Room to +5%** | 1 = +5% is at most 1.5 x ATR14 from the expected open; 1 = no recent high within +5% that has already capped the stock, or the stock is breaking above it on volume. |
| **The stock's own touch rate** | From OHLCV, when available: over the last 60 sessions, the share of days from whose open the stock reached +5% within 10 sessions. 2 = at least 50%; 1 = 35-49%; 0 = under 35% or unavailable. |
| **Tape** | 1 = the index proxy (XIC or ONEQ) is at or above its 10-day SMA and the stock's sector isn't in a broad selloff. |

**Verdicts:**
- **8-10: BUY at next open.**
- **5-7: BUY-HALF**, i.e. half the reference size.
- **0-4: NO-BUY.**

These thresholds are starting points. Recalibrate them after 20 or more logged verdicts (see Logging).

## Required flow

1. **List the tickers** and restate, in one line each, the thesis being tested.
2. **Run the research on the highest-available Opus model.** Spawn a subagent via the Agent tool with `model: "opus"` per ticker (or one for the batch). Brief it with:
   - the ticker, the thesis, entry, stop and ATR%;
   - the trade plan above, and the question "better than the ~47% base rate under this plan?";
   - the veto list and the scorecard;
   - an instruction to build both the bull and bear case and score each factor with sources, rather than reaching an overall conclusion first.

   Track which model did which work. If an Opus-capable subagent isn't available, say so, run the research in the current model, and record the substitution.
3. **Research, don't assume.** Use real web search and fetch against public sources: the catalyst's primary source, recent analyst actions with their stated reasoning, IR material and the event calendar inside the window, and recent news. For the price factors, use OHLCV from the Qtrade sheet or `ohlcv_*.csv` (from `dump_ohlcv.py`) when available. Every point awarded needs a source URL and date, or a computed figure. No source, no point.
4. **Review the findings yourself in the persona.** Check each veto and each point. Override the subagent where a point rests on thin support, in either direction: dock points that aren't earned, and don't dock points for objections the persona section says to ignore.
5. **Give the verdict** per ticker:
   - **BUY at next open**, **BUY-HALF**, or **NO-BUY**;
   - the score breakdown, or the veto that fired;
   - two to four sentences on the strongest evidence for and against, with sources;
   - the single biggest risk;
   - what would flip the verdict.

   For several tickers, start with a table (ticker | verdict | score or veto | key support | key risk), then the detail.
6. **Calibration check.** If five or more names were reviewed and none scored BUY or BUY-HALF, say so explicitly. Name the closest miss and the factor that held it back, so Abe can see whether the bar or the batch is the problem. Don't change scores to force a BUY.
7. **Execution reminder** for any BUY or BUY-HALF:
   - skip if the open is more than 1 ATR above the recommended entry, or (for the TSX screen) more than 2% above the prior close;
   - recompute the +5% limit and the stop from the actual open (`fill_check.py` does this);
   - time stop at 10 sessions.
8. **Logging.** If the Qtrade folder is reachable, append one row per ticker to `verdicts_log.csv` there: `date,market,ticker,verdict,score,veto,entry,stop`, creating it with that header if missing. Otherwise put those rows at the end of the report for Abe to keep. This log is how BUY vs NO-BUY outcomes get checked against `backtest_list_agg.py` later.
9. **Close with a "Models used" line** naming each model actually invoked and what it did. Call out any fallback away from Opus by name.

## Important reminders

- This is a trade-readiness opinion, not investment advice. State findings and reasoning, not certainty about prices.
- Vetoes are absolute. Never score your way around one.
- BUY-HALF is a real outcome for a decent but imperfect setup, not a hedge to avoid deciding. Use it when the score says so.
- Don't skip the fresh Opus pass even when earlier research exists; the value is the independent second look.
- The buy decision and any order stay Abe's to make.
- Never fabricate which model handled a step.