---
name: "qsx-stock-aggresive"
description: "Runs the full aggressive TSX stock screen in one shot: score the universe with screen v2, verify fresh company catalysts from public news, and write the final shortlist to the List_agg tab."
---

# QSX Stock Aggressive Screen — TSX (screen v2)

Use this when Abe asks to bypass the 50-day regime gate and the sector gate for TSX and wants the full aggressive shortlist in one pass.

As of Oct 26 2026 this runs **screen v2 with the TSX rules**, built from a backtest of every `List_agg` pick (buy the next open, +5% limit sell). It uses the same scoring engine as the Nasdaq screen. The gate, list size and gap rules are TSX-specific and live in the `TSX` block of `config.py`. TSX is the default market, so just make sure `MARKET` is unset or set to `TSX`.

Market specifics: CAD, universe `universe.csv` (215 names), index proxy XIC, sheet tabs `Index_Daily`, `Universe_OHLCV` and `List_agg`. Universe filter: price >= $5.00, 20-day median dollar volume >= $5,000,000 CAD, and at least 60 trading days of history.

## What v2 does on TSX (enforced in code)

- **Scoring** (`qsx_stock_aggresive.score_candidates_v2`), weights 30/25/25/10/10:
  - Momentum = blended 10-day and 20-day return minus the median of the same GICS sector, from `sector_map.csv`. Sectors with fewer than 5 names use the universe median.
  - Volume = last session's volume ÷ the 20-session median, capped at 4x.
  - Structure = proximity to the 20-day high: `max(0, 100 - 25 x ATRs below the high)`.
  - Liquidity = percentile of the 20-day median dollar volume.
  - Quality = an exclusion flag. An excluded name scores 0; an eligible name gets the full 10 points.
- **Exclusions:** names in `exclusions_tsx.csv`, plus any ticker with no bar on the latest session (halted or delisted). ACO.X and CU are seeded there for the Emera/Canadian Utilities stock-for-stock deal.
- **Hard gate** (`run_qsx_aggresive.py`):
  - Score >= 70.
  - ATR14 from 2.0% up to, but not including, 5.0%.
  - Not excluded.
  - Signal-day rule: the close was in the top half of the day's range, and the day's move was no more than +8%.
  - There is no cap on the number of names.
- **Regime line:** every run prints XIC's last close against its 10-day SMA. It is informational only; it doesn't change the gate. When XIC is below the SMA, tell Abe to consider sizing down.
- **Write step** (`write_list_agg.py`):
  - Aborts the whole write if any row fails validation: ticker not a bare symbol, not in `universe.csv`, a duplicate, on the exclusions list, a non-numeric or empty numeric field, or a missing catalyst or URL. This is what stops a bare "Loblaws" row like Oct 22's.
  - Re-applies the signal-day rule from `qsx_candidates_diag.csv`.
- **Feedback:** every run prints the trailing hit rate of the last 20 `List_agg` picks, and lists open picks past the 10-session time stop.

Caveat to state when relevant: in the Oct 26 replay, the "close in the top half of the range" rule would have removed all six past TSX winners (EFX Oct 2, RUS ×2, FFH, ATZ), not just the losers. Over 39 days of history, v2 also picked a weaker pool than the original scoring before the catalyst check (35% vs 47% hit). Abe chose to run all the changes anyway, so watch the trailing hit rate. If it lags, the switch is `GAP_RULES_SCOPE="earnings"` in the TSX block of `config.py`, which turns off the TSX signal-day and 2%-open rules.

## Required flow

1. **Confirm the market is TSX.** `MARKET` must be unset or `TSX`. The first line of output must read `Market: TSX [screen v2]`; if it doesn't, stop.
2. **Run the screen:** `python run_qsx_aggresive.py`. It writes `qsx_candidates.csv`, plus `qsx_candidates_diag.csv` holding sub-scores, sector, close location, day return and rejection reasons. It prints:
   - the regime line,
   - the candidate list,
   - the per-sector counts,
   - the trailing hit-rate line.

   Keep the regime and trailing lines for the report.
3. **Catalyst research**, for each candidate. Use real public web and news research, and verify a real catalyst dated within the last 3 trading days. That means the event itself, not commentary about it, with a URL you actually fetched and confirmed. Exclude, naming the reason, when:
   - **no fresh verifiable catalyst** exists (no catalyst found, catalyst too old, or only routine items found);
   - **analyst actions come with no stated rationale.** A price-target change or rating move counts only if the source gives its reasoning, or it is clearly tied to a dated company event within the window. Examples that count: Acumen raising EFX after the data-center contract; Scotiabank initiating on ATZ after earnings. A bare number change with no reasoning does not count; HPS.A's Oct 13 NBF raise is the example. Quote the stated rationale in the catalyst text;
   - it is a **pending merger target or deal-arbitrage name**, i.e. the catalyst is a signed stock-for-stock or cash deal that pins the price, as ACO.X did. Add it to `exclusions_tsx.csv` (`ticker,reason,until,added`) with `until` set to the expected close date, or blank;
   - **earnings fall in the next 10 sessions**. Add to the exclusions file with `until` set to the day after earnings;
   - there is a **halt, cease-trade order or delisting notice**. Add to the exclusions file with `until` left blank.
4. **Write the final CSV** with the List_agg schema: `ticker, score, atr_pct, entry, target, stop, shares, target_upside_pct, catalyst, catalyst_url`. The ticker cell holds the bare symbol only (e.g. `TECK.B`, `BIP.UN`), with every numeric field filled in.
5. **Append it** with `python write_list_agg.py <final csv>`. If validation aborts, fix the CSV and rerun; never hand-edit the sheet. Only report success after the script prints "Appended". The block lands in the results-tracking sheet (`config.GOOGLE_OUTPUT_SHEET_ID`), tab `List_agg`.
6. **Report**, in CAD:
   - the final shortlist, with each catalyst and its stated rationale;
   - the regime line, saying "size down" if XIC is below its 10-day SMA;
   - the trailing hit-rate line, plus any names past the time stop;
   - exclusions added this run;
   - a line saying the run skipped the 50-day regime and sector gates by design.

   End with the next-morning execution rules below.

## Next-morning execution rules (include in every report)

- The CSV `entry` is the prior close; the trade is bought at the next open. After the open, run `python fill_check.py TICKER=<open> ...` (or `--csv <final csv>`). It prints BUY or SKIP per name:
  - SKIP if the open is more than 1 ATR above the recommended entry.
  - SKIP if the open is more than 2% above the prior close; wait a session.
  - BUY otherwise. Target and stop are recomputed from the actual open (open + 2.5 ATR, open − 1.5 ATR), alongside the +5% limit-sell level.
- **Time stop:** exit any position that hasn't filled after 10 sessions. `fill_check.py` prints the date.

Opens are typed in, not fetched from Questrade, because a Questrade call spends the single-use refresh token used by the scheduled daily pull.

## Sector data

`sector_map.csv` (ticker, GICS sector) covers all 215 names in `universe.csv`. Claude built it on Oct 16 2026 from general knowledge, because the iShares XIC holdings export couldn't be downloaded; Abe then changed EFN to Information Technology. A few names are judgement calls, so treat it as good enough for screening, not authoritative: DOL, BYD, ALA, SPB, AIF, CIGI, SOBO, VNP, and SIA/EXE/CSH.UN. If a scored candidate's sector looks wrong, flag it. A newly added `universe.csv` ticker has no sector until a row is added; it then falls back to the universe median for momentum.

## Commands

- Run the screen: `python run_qsx_aggresive.py`
- Write final results: `python write_list_agg.py <final csv>`
- Next-morning fill check: `python fill_check.py TICKER=<open> ...`
- Trailing hit rate on its own: `python dump_ohlcv.py` then `python backtest_list_agg.py TSX --last 20`
- Tests: `python -m pytest tests`

## Important reminders

- Do not silently skip catalyst verification. A score-only shortlist is not enough; only names with a genuine, fresh, reasoned catalyst stay in the final table.
- Do not claim the sheet write succeeded unless the script printed "Appended".
- Never mix TSX and Nasdaq rows in one run; say which market the report covers.
- Thresholds live in `config.py` under the `TSX` block (`SCORE_MIN`, `ATR_PCT_MAX`, `GAP_RULES_SCOPE`, `MAX_SIGNAL_DAY_RET_PCT`, ...). Change them there, not by overriding the gate by hand in chat.