---
name: "qsx-nasdaq-aggressive"
description: "Runs the full aggressive Nasdaq stock screen in one shot: score the ONEQ-sourced universe with screen v2, verify fresh company catalysts from public news, and write the final shortlist to the List_agg_NASDAQ tab. USD, $10M min dollar volume."
---

# QSX Nasdaq Aggressive Screen (screen v2)

Use this when Abe asks to bypass the 50-day regime gate and the sector gate for Nasdaq and wants the full aggressive shortlist in one pass.

As of Oct 25 2026 this skill runs **screen v2**, built from a backtest of every `List_agg_NASDAQ` pick (buy the next open, +5% limit sell). v2 is Nasdaq-only. It switches on automatically when `MARKET=NASDAQ` (`config.SCREEN_VERSION = 2`). The TSX skill (`qsx-stock-aggresive`) deliberately stays on v1 and its output is unchanged, so don't carry these rules over to TSX unless Abe asks.

Market specifics:
- USD throughout, not CAD.
- Universe and index proxy: ONEQ (Fidelity Nasdaq Composite Index ETF), not XIC.
- Sheet tabs: `Index_Daily_NASDAQ`, `Universe_OHLCV_NASDAQ` and `List_agg_NASDAQ`.
- Universe filter: price >= $5.00, 20-day median dollar volume >= $10,000,000, and at least 60 trading days of history.

## What v2 does (enforced in code)

- **Scoring** (`qsx_stock_aggresive.score_candidates_v2`), weights 30/25/25/10/10:
  - Momentum = blended 10-day and 20-day return minus the median of the same GICS sector, from `sector_map_nasdaq.csv`. Sectors with fewer than 5 names, or unmapped tickers, use the universe median instead.
  - Volume = last session's volume ÷ the 20-session median, capped at 4x.
  - Structure = proximity to the 20-day high: `max(0, 100 - 25 x ATRs below the high)`.
  - Liquidity = percentile of the 20-day median dollar volume.
  - Quality = an exclusion flag. An excluded name scores 0; an eligible name gets the full 10 points.
- **Exclusions:** names listed in `exclusions_nasdaq.csv`, plus any ticker with no bar on the latest session (halted, delisted, merger closed, moved exchange).
- **Hard gate** (`run_qsx_aggresive.py`):
  - Score >= 75. Raise it to >= 78 when ONEQ closed below its 10-day SMA (the light regime check).
  - ATR14 from 2.0% up to, but not including, 5.0%.
  - Not excluded.
  - Only the top 12 by score (top 6 when the regime is off) go on to catalyst research.
- **Write step** (`write_list_agg.py`):
  - Aborts the whole write if any row fails hygiene: ticker not a bare symbol, not in `universe_nasdaq.csv`, a duplicate, on the exclusions list, a non-numeric field, or a missing catalyst or URL.
  - Drops `[EARNINGS]` rows whose signal-day close was in the bottom half of its range (from the `_diag.csv`).
  - Keeps at most 2 names per GICS sector.
- **Feedback:** every run prints the trailing hit rate of the last 20 `List_agg_NASDAQ` picks, and lists open picks past the 10-session time stop.

The score is a filter, not an edge. In the backtest every scoring variant hit +5% on only 36-44% of picks before the catalyst check. Most of the edge comes from the catalyst standard and the exit rules below, so don't relax them because a score is high.

## Required flow

1. **Set the market:** `set MARKET=NASDAQ` (Windows) or `export MARKET=NASDAQ` (bash). Confirm it before running anything. The script's first line must say `Market: NASDAQ [screen v2]`; if it doesn't, stop.
2. **Run the screen:** `python run_qsx_aggresive.py`. It writes `qsx_candidates_nasdaq.csv`, plus `qsx_candidates_nasdaq_diag.csv` holding sub-scores, sector, close location, day return and rejection reasons. It prints:
   - the regime line and the gate used,
   - the candidate list,
   - the per-sector counts,
   - the trailing hit-rate line.

   Keep the regime and trailing-hit-rate lines for the report.
3. **Catalyst research**, for each candidate only. Use real public web and news research, and verify a real catalyst dated within the last 3 trading days. That means the event itself, not commentary about it, with a URL you actually fetched. Exclude a name when:
   - no fresh verifiable catalyst exists; name the reason (no catalyst found, catalyst too old, or only routine items found);
   - it is a **pending M&A target or deal-arbitrage name**, i.e. a signed cash or stock deal where the price is pinned to the deal terms (for example QRVO before the Skyworks close). Never list these. Add them to `exclusions_nasdaq.csv` (`ticker,reason,until,added`) with `until` set to the expected close date;
   - **earnings fall inside the next 10 sessions**. Add to the exclusions file with `until` set to the day after earnings;
   - there is a halt, a delisting notice, or a move off Nasdaq (e.g. to TXSE). Add to the exclusions file with `until` left blank.
4. **Tag post-earnings names.** If the catalyst is an earnings or guidance release, start the catalyst text with `[EARNINGS]`. In the diag file, check that `close_loc` >= 0.5, meaning the close was in the top half of the signal day's range. If it isn't, exclude the name ("wait a session"); the write step enforces this anyway.
5. **Apply the sector cap:** at most 2 names per GICS sector. If more than two in a sector have good catalysts, keep the two strongest. The write step keeps the two highest scores and drops the rest.
6. **Write the final CSV** with the List_agg schema: `ticker, score, atr_pct, entry, target, stop, shares, target_upside_pct, catalyst, catalyst_url`. The ticker cell holds the bare symbol only, never notes like "close call".
7. **Append it** with `python write_list_agg.py <final csv>`, with `MARKET=NASDAQ` still set. If the hygiene check aborts, fix the CSV and rerun; never hand-edit the sheet. Only report success after the script prints "Appended". The block lands in the results-tracking sheet (`config.GOOGLE_OUTPUT_SHEET_ID`), tab `List_agg_NASDAQ`.
8. **Report**, in USD:
   - the final shortlist;
   - the regime line and gate used;
   - the trailing hit-rate line, plus any names past the time stop;
   - exclusions added to the file this run;
   - a line saying the run skipped the 50-day regime and sector gates by design, with the light 10-day ONEQ check applied.

   End with the next-morning execution rules below.

## Next-morning execution rules (include in every report)

- The CSV `entry` is the prior close; the trade is bought at the next open. After the open, run `python fill_check.py TICKER=<open> ...` (or `--csv <final csv>`). It prints BUY or SKIP per name:
  - SKIP if the open is more than 1 ATR above the recommended entry.
  - SKIP if the name is `[EARNINGS]` and opened more than 2% above the prior close; wait a session.
  - BUY otherwise. Target and stop are recomputed from the actual open (open + 2.5 ATR, open − 1.5 ATR), alongside the +5% limit-sell level.
- **Time stop:** exit any position that hasn't filled after 10 sessions. `fill_check.py` prints the date.

Opens are typed into `fill_check.py` rather than fetched from Questrade on purpose. A Questrade call spends the single-use refresh token, which would collide with the scheduled daily pull.

## Sector data

`sector_map_nasdaq.csv` (GICS sector per ticker) sits alongside `universe_nasdaq.csv`. v2 genuinely uses it, both for sector-relative momentum and for the sector cap. Most tickers were matched in bulk against a third-party GICS-labeled dataset (JerBouma/FinanceDatabase on GitHub), and a few were filled in individually (`DSG`, `TRMD.A`, `PSQL`). It is not an exchange-published holdings file the way XIC's is for TSX, so say so in reports rather than presenting it as equally authoritative. If a scored candidate's sector looks wrong, flag it.

The exact-match/prefix-search symbol resolution in `questrade_client.py` has TSX-specific quirks (`.TO` suffix querying, preferred-share segment exclusion) that are switched off for `MARKET=NASDAQ`. If `run_daily.py` logs unexpected `WARN: no symbolId found` lines for Nasdaq tickers, diagnose the naming convention rather than assuming the TSX fix applies.

## Commands

- Set the market: `set MARKET=NASDAQ` (lasts only for the current terminal).
- Run the screen: `python run_qsx_aggresive.py`
- Write final results: `python write_list_agg.py <final csv>`
- Next-morning fill check: `python fill_check.py TICKER=<open> ...`
- Trailing hit rate on its own: `python dump_ohlcv.py` then `python backtest_list_agg.py NASDAQ --last 20`
- Tests: `python -m pytest tests`

## Important reminders

- Do not silently skip catalyst verification. A score-only shortlist is not enough; only names with a genuine, fresh catalyst stay in the final table.
- Do not claim the sheet write succeeded unless the script printed "Appended".
- Never mix Nasdaq and TSX rows in one run. Confirm `MARKET` and say which market the report covers.
- Thresholds live in `config.py` under the `NASDAQ` block (`SCORE_MIN`, `SCORE_MIN_REGIME_OFF`, `MAX_CANDIDATES`, `ATR_PCT_MAX`, `MAX_PER_SECTOR`, ...). Change them there, not by overriding the gate by hand in chat.
- The results-tracking sheet must have the service account shared on it as Editor. If the write fails with a permission error, check that first.